SELECT fabricante
FROM automoveis;